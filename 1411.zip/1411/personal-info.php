<?php include 'includes/header.php'; ?>

<main>
    <h1>Personal Info</h1>
    <p>Here you can learn more about my background and personal information.</p>
</main>

<?php include 'includes/footer.php'; ?>
