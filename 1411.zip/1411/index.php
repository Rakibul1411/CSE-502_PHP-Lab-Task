<?php include 'includes/header.php'; ?>

<main>
    <h1>Welcome to My Portfolio</h1>
    <p>Explore my work, skills, and experiences as a web developer.</p>
</main>

<?php include 'includes/footer.php'; ?>
