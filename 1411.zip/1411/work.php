<?php include 'includes/header.php'; ?>

<main>
    <h1>Work Experience</h1>
    <p>I have worked as a web developer on various projects involving PHP, HTML, CSS, and JavaScript.</p>
</main>

<?php include 'includes/footer.php'; ?>
