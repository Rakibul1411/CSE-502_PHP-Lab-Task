<!-- footer.php -->
</main>
    <footer class="footer">
        <p>&copy; 2025 WebTech Lab Final. All rights reserved.</p>
    </footer>
</body>
</html>