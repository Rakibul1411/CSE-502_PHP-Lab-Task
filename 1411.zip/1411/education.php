<?php include 'includes/header.php'; ?>

<main>
    <h1>Education</h1>
    <p>I completed my undergraduate degree in Software Engineering from the University of Dhaka.</p>
</main>

<?php include 'includes/footer.php'; ?>
