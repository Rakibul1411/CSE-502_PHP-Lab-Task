<?php include 'includes/header.php'; ?>

<main>
    <h1>About Me</h1>
    <p>I am a web developer with experience in PHP, HTML, CSS, and JavaScript. I love building dynamic and responsive websites.</p>
</main>

<?php include 'includes/footer.php'; ?>

<!-- Include JS File -->
<script src="js/script.js"></script>